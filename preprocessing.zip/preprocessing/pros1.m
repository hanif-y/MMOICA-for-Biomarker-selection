% Correct imbalanced data using k-means sampeling
load mirdata1
NonCancer;
 Y = pdist(ncd);
 Z = linkage(Y,'single');
% %dendrogram(Z)
 [idx,C] = kmeans(ncd,5);
for i=1:5
r=find(idx==i);
d=ncd(r,:);
D1 = pdist2(d,C(i,:));
a=(min(D1)+(mean(D1)+min(D1))/2)/2;
e=find(D1<=a+3.5);
dd.p{i}=d(e,:);
end
NCF=[dd.p{1}' dd.p{2}' dd.p{3}' dd.p{4}' dd.p{5}'];