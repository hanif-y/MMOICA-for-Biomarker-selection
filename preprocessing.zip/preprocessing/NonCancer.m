a=find(G==13);
NCL(1,:)=lable(a);
NCL(2,:)=num2cell(G(a));
NCL(3,:)=num2cell(0);
ncd=mdata(:,a)';