%SNR and FDR ranking of selected variables (Bestfreq1)
[fdr,snr]=fidr(D,R);
sw=snr(Bestfreq1);
sw=round(sw,3);
fw=fdr(Bestfreq1);
fw=round(fw,3);
for i=1:11
tt(i)=find(ranking==Bestfreq1(1,i));
end
tt=tt';