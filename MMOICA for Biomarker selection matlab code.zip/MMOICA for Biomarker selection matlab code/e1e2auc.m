AUC=AUC';
AUC=round(AUC,4);
e2=round(e2,4);
e1=round(e1,4);
e2=e2';