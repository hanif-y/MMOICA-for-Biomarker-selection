This program implements the Modified Multi Objective Imperialist Competitive Algorithm for the selection of micro-RNAs 
with biomarker potency.Run the MAIN.m file to run the program. If you need to review the results for ovarian cancer data
(This data has been accessed via GSE106817 accession number at https://www.ncbi.nlm.nih.gov/geo/ and is available at 
http://www.biomarkers.ai/microRNA/ with the same number) without executing the program, please open the results folder 
and drag the newsolbestf.mat file.The preprocessing folder contains the necessary code to get the optimal data from raw 
data.