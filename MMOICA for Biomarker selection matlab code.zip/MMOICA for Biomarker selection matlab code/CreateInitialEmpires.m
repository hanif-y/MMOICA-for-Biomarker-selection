%% This function creates initial empires.
% Initial Empires are created based on the NumOfInitialImperialists parameter. 
% Costs of colonies and imperialists are also calculated in every newly
% created empire.
function Empires = CreateInitialEmpires(InitialCountries,InitialCost,AlgorithmParams, ProblemParams)
AllImperialistsCost = InitialCost(1:AlgorithmParams.NumOfInitialImperialists,:);
if (size(find(max(AllImperialistsCost)>0),2) == ProblemParams.M)% if both objective function max values are > 0...
    AllImperialistsPower = 1.3 * repmat(max(AllImperialistsCost),size(AllImperialistsCost,1),1) - AllImperialistsCost;
else
    AllImperialistsPower = 0.7 * repmat(max(AllImperialistsCost),size(AllImperialistsCost,1),1) - AllImperialistsCost;
end

AllImperialistsPower_ = (sum(AllImperialistsPower')')/ProblemParams.M;
AllImperialistNumOfColonies = round(AllImperialistsPower_/sum(AllImperialistsPower_) * AlgorithmParams.NumOfAllColonies);
AllImperialistNumOfColonies(end) = AlgorithmParams.NumOfAllColonies - sum(AllImperialistNumOfColonies(1:end-1));
RandomIndex = randperm(AlgorithmParams.NumOfCountries);

Empires(AlgorithmParams.NumOfInitialImperialists).ImperialistPosition = 0;

for ii = 1:AlgorithmParams.NumOfInitialImperialists
    AllColoniesCost = InitialCost;
    AllColoniesPosition = InitialCountries;
    AllImperialistNumOfColonies(ii) = AllImperialistNumOfColonies(ii) + 1;
    
    R = RandomIndex(1:AllImperialistNumOfColonies(ii));
    RandomIndex = RandomIndex(AllImperialistNumOfColonies(ii)+1:end);
    
    [AllColoniesCost, SortInd] = NonDominationSort(AllColoniesCost(R,:),ProblemParams.M); % apply non-domination sorting...
    AllColoniesPosition = AllColoniesPosition(SortInd,:); % Sort the population with respect to their cost.

    Empires(ii).ImperialistCost = AllColoniesCost(AllColoniesCost(:,ProblemParams.M+1) == 1,1:ProblemParams.M);
    Empires(ii).ImperialistPosition = AllColoniesPosition(AllColoniesCost(:,ProblemParams.M+1) == 1,1:end);
    
    Empires(ii).ColoniesCost = AllColoniesCost(AllColoniesCost(:,ProblemParams.M+1) ~= 1,1:ProblemParams.M);
    Empires(ii).ColoniesPosition = AllColoniesPosition(AllColoniesCost(:,ProblemParams.M+1) ~= 1,1:end);
    
    %%Compute the Total Cost of an Empire...
    Empires(ii).TotalCost = size(Empires(ii).ImperialistCost, 1);        
    Empires(ii) = PossesEmpire(Empires(ii), ProblemParams, AlgorithmParams);
end