%evaluation of classifier performance of original variables, after FDR filtering and after final embedded method
%The results are stored for 20 times the calculation of the objective function in jj matrices.
for i=1:20
    [jj(i,:,1),~]=crossmain(D,R,1:2565,1);
    [jj(i,:,2),~]=crossmain(D,R,indf',1);
    [jj(i,:,3),~]=crossmain(D,R,Bestfreq1,1);
end