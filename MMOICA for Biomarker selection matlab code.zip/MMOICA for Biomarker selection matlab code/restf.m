global Z;
global R;
global indf;
global ranking
R=cell2mat(L(3,:));
BestSol.Position=indf(Empires.ImperialistPosition);

for ll=1:size(BestSol.Position,1)
fla(ll,:)=prn(BestSol.Position(ll,:),:);
for i=1:size(BestSol.Position,2)
    mir(ll,i)=idn(find(strcmp(idn(:,2),fla(ll,i))));
end
end
k=0;
[B,index]=sortrows(Empires.ImperialistCost,1);
[B,index1]=sortrows(B,2);
indexx=index(index1);
for i=indexx(1:3,:)'
    k=k+1;
qq=(Empires.ImperialistPosition(i,:));
Bestfreq.p{k}=repeatf(qq);
% yz=Z(Bestfreq.p{k},:);
zzz(k,:)=MOP14(Bestfreq.p{k},1);
qq=(BestSol.Position(i,:));
Bestfreq.q{k}=repeatf(qq);

end
qq1=[Bestfreq.q{1} Bestfreq.q{2} Bestfreq.q{3}];
% qq1=[Bestfreq.q{1}];
Bestfreq1=repeatf(qq1);

fla1=prn(Bestfreq1,:);
for i=1:size(Bestfreq1,2)
    mirbest(i,:)=idn(find(strcmp(idn(:,2),fla1(i))));
end
yz=D(Bestfreq1,:);

G1=clustergram(yz,'Standardize',2,'cluster',3)
G2=set(G1,'RowLabels',mirbest,'ColumnLabels',R,'Dendrogram',4)
