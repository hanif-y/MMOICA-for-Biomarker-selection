%% Main code of MMOICA feature selection
%Programmed by Hanif Yaghoobi
% MOICA has been coded in the original version by Zhavat Sherinov et al (Sherinov and �nveren, 2017) and its original MATLAB code is available at the following URL:
%http://www.zhavatsherinov.com/moica.html
%Zhavat SHERINOV and Ahmet �NVEREN, �Multi-objective imperialistic competitive algorithm with multiple non-dominated sets for the solution of global optimization problems�, Soft Computing, Springer, 2017.
%We have modified the original code to obtain a discrete version of the algorithm in order to solve the feature selection problem.
%For correspondence with Hanif Yaghoobi, developer of these codes.
%My email :hanif_yaghoubi@tabrizu.ac.ir

clc
clear all
close all
load OvariC.mat
%%
global Z;
global R;
global pp; 
global s;
global ranking;
global indf;

%% FDR filtering and mRMR ranking
R=cell2mat(L(3,:));
[fdr,snr,indo,indf,snrf,fdrf,SD,Sf]=fidrf(D,R,0.5);
nf=size(Sf,1);
ranking = indf(mRMR(Sf', (R'*2-1), nf));
%% Classifier type and feature number selection 
s=1;
pp=10;
Z=Sf;
%% MOICA runing
MOICA1
%% Make final results
restf
