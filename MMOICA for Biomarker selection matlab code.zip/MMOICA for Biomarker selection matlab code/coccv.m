% ROC Curve Plot for L1-SVM,Discriminant Analysis,Classification Tree,Ensemble of 10 tree & adaboost method,Naive Bayes,Linear Classification

for s=1:7
[e1(s,:),e2(s,:),xx.p{s},yy.p{s},AUC(s,:)]=crossmain(D,R,ranking(1,1:10),s);
plot(xx.p{s},yy.p{s},'-.','LineWidth',2.5)
hold on
end
xlabel('False positive rate'); ylabel('True positive rate');
title('ROC of classification methods');
legend('L1-SVM,RBF','Discriminant Analysis','Classification Tree','Ensemble of 10 tree & adaboost method ','Naive Bayes','Linear Classification','L1-SVM,Linear','Location','Best')
ax = gca;
ax.FontSize = 18;
ax.LineWidth=2;
ax.YLim = [-0.05 1.05];
ax.XLim = [-0.05 1.05];