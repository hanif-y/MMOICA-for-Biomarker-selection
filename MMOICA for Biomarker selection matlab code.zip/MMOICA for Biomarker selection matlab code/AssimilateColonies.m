%% Assimilation of colonies
% Colonies are assimilated towards one of the randomly selected
% imperialists in the global non-dominated solution set. After assimilation
% Economic changes operation is applied with 20% probability.
function TheEmpire = AssimilateColonies(TheEmpire,ProblemParams, Empires)

GlobalNDS.Cost = [];
GlobalNDS.Position = [];

for i=1:numel(Empires)
    GlobalNDS.Position(end+1:end+size(Empires(i).ImperialistPosition),:) = Empires(i).ImperialistPosition;
    GlobalNDS.Cost(end+1:end+size(Empires(i).ImperialistPosition),:) = Empires(i).ImperialistCost;
end

[GlobalNDS.Cost, NewIn] = NonDominationSort(GlobalNDS.Cost,ProblemParams.M); % apply non-domination sorting...
GlobalNDS.Position = GlobalNDS.Position(NewIn,:);

GlobalNDS.Position = GlobalNDS.Position(GlobalNDS.Cost(:,ProblemParams.M+1) == 1,:);
GlobalNDS.Cost =  GlobalNDS.Cost(GlobalNDS.Cost(:,ProblemParams.M+1) == 1,1:ProblemParams.M);

%%

NumOfColonies = size(TheEmpire.ColoniesPosition,1);
% tk=0;
% for l=randi(NumOfColonies,[1 round(NumOfColonies/1.2)]);
for l=1:round(NumOfColonies/1)
R = randi(size(GlobalNDS.Position,1), 1);
ks=unidrnd(ProblemParams.NPar,[1 round(ProblemParams.NPar/2)]);
Vector = GlobalNDS.Position(R,ks);

% a=0;
% if ProblemParams.M == 2 && rand() > 0.5
%     b=5;
% else
%     b=2;
% end
% r = a + (b-a)*rand();
% 
% variationInAssimilation = r * rand(size(Vector)) .*Vector;% rand(size(Vector)) here is theta...
% rr=randi(size(TheEmpire.ColoniesPosition,1), [1 round(size(TheEmpire.ColoniesPosition,1)/2)]);
% TheEmpire.ColoniesPosition(rr,ks) = repmat(Vector,size(TheEmpire.ColoniesPosition(rr,ks),1),1);
templec=TheEmpire.ColoniesPosition(l,:);
templec(1,ks)=Vector;

GlobalNDS.Cost = [];
GlobalNDS.Position = [];

for i=1:numel(Empires)
    GlobalNDS.Position(end+1:end+size(Empires(i).ImperialistPosition),:) = Empires(i).ImperialistPosition;
    GlobalNDS.Cost(end+1:end+size(Empires(i).ImperialistPosition),:) = Empires(i).ImperialistCost;
end

cst = feval(ProblemParams.CostFuncName,templec,ProblemParams.CostFuncExtraParams);
GlobalNDS.Cost(1+size(Empires(numel(Empires)).ImperialistPosition,1),:)=cst;
[GlobalNDS.Cost, ~] = NonDominationSort(GlobalNDS.Cost,ProblemParams.M);
if GlobalNDS.Cost(end,ProblemParams.M+1) == 1 || GlobalNDS.Cost(end,ProblemParams.M+1) == 2
% tk=tk+1;
TheEmpire.ColoniesPosition(l,:) = templec;
% TheEmpire.ColoniesPosition(NumOfColonies+tk,:) = templec;
% TheEmpire.ColoniesCost(NumOfColonies+tk,:) = cst;
end
end
%% Economic Changes...
% if rand() > 0.8
%     r = (ProblemParams.VarMax - ProblemParams.VarMin);
%     w = zeros(size(r));
%     for i=1:numel(r)
%         w(i) = (ProblemParams.VarMax(i)*rand())^(rand()/r(i)) - (abs(ProblemParams.VarMin(i))*rand())^(rand()/r(i));
%     end
% TheEmpire.ColoniesPosition = TheEmpire.ColoniesPosition .* repmat(w,size(TheEmpire.ColoniesPosition,1),1);    
% end
%% End of Economic Changes...

% MinVarMatrix = repmat(ProblemParams.VarMin,NumOfColonies,1);
% MaxVarMatrix = repmat(ProblemParams.VarMax,NumOfColonies,1);
% 
% TheEmpire.ColoniesPosition=max(TheEmpire.ColoniesPosition,MinVarMatrix);
% TheEmpire.ColoniesPosition=min(TheEmpire.ColoniesPosition,MaxVarMatrix);
