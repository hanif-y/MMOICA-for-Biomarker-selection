function [fdr,snr]=fidr(x,L)
r1= L==0;
r2= L==1;
x1=x(:,r1);
x2=x(:,r2);
fdr=((mean(x1,2)-mean(x2,2)).^2)./(var(x1,0,2)+var(x2,0,2));
snr=((mean(x1,2)-mean(x2,2)))./(sqrt(var(x1,0,2))+sqrt(var(x2,0,2)));