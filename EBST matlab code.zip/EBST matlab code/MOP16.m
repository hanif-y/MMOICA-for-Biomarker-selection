function z=MOP16(x,~)
global myGlob;
global Z;
global R;
global kh
global ranking;
global indf;

global pp;

[a , ~]=size(x);
tic
 Y=(abs(R-1)+1)';
for k=1:a
    y=Z(x(k,:),:);
    [r,~]=kmeans(y',2,'Distance','cosine');
    if size(find(r(1:end,:)==2),1)>size(r,1)/2
e1=r==2;
e2=r==1;
r(e1,:)=1;
r(e2,:)=2;
    end

% net = selforgmap([1 2]);
% net.trainParam.showWindow=0;
% [net,~] = train(net,y);
% Y1 = net(y);
% if size(find(Y1(1,1:30)==0),2)>18
% r=(abs(Y1(2,:)-1)+1)';
% else
% r=(abs(Y1(1,:)-1)+1)'; 
% end
% q=[];
    for uu=1:pp
    q(:,uu)=find(ranking==indf(x(k,1),1));
    end


z8(1,k)=mean(q)/size(Z,1);
z3(1,k)=(1/size(Z,2))*sum(~eq(Y,r));
end
toc
switch kh
    case 2
z=[z3;z3]';
    case 3 
z=[z3;z8]';
end
myGlob = myGlob + size(x,1);