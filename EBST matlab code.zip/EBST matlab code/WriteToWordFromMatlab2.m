
global A;
global C;
global AB;
global xx;
global yy;
global yz;
global mirbest;
global R;
global AA;
global Ca;
global ABa;
global R1;
global yz1;
global xx1;
global yy1;
global gna;
[file,path] = uiputfile;
	WordFileName=file;
	CurDir=path;
	FileSpec = fullfile(CurDir,WordFileName)
	[ActXWord,WordHandle]=StartWord(FileSpec)
    
    fprintf('Document will be saved in %s\n',FileSpec);
    
    
    Style='Heading 1'; %NOTE! if you are NOT using an English version of MSWord you get
    % an error here. For Swedish installations use 'Rubrik 1'. 
    TextString='Final Results from EBST';
    WordText(ActXWord,TextString,Style,[0,2]);%two enters after text
    
    Style='Normal';
    TextString='This reports are generated automatically by EBST';    
    WordText(ActXWord,TextString,Style,[0,1]);%enter after text
    style='Heading 1';
    text='Table of Contents';
    WordText(ActXWord,text,style,[1,1]);%enter before and after text 
    WordCreateTOC(ActXWord,1,3);
 ActXWord.Selection.InsertBreak; %pagebreak


    style='Heading 1';
    text='Analysis Tables for Original Dataset';
    WordText(ActXWord,text,style,[1,2]);%enter before and after text 
    
    Style='Heading 2';
    TextString='Mean Absolute Error of External/Internal Cross Validation and Classification Edge';
    WordText(ActXWord,TextString,Style,[0,0]);%enter after text
  
    [NoRows,NoCols]=size(A);          
    %create table with data from DataCell
    WordCreateTable(ActXWord,NoRows,NoCols,A,1);%enter before table
    
    Style='Heading 2';
    TextString='Selected Biomarkers and their SNR, FDR, mRMR ranking and correlation with classes';
    WordText(ActXWord,TextString,Style,[2,0]);%enter after text
  
    [NoRows,NoCols]=size(C);          
    %create table with data from DataCell
    WordCreateTable(ActXWord,NoRows,NoCols,C,1);%enter before table
    
    Style='Heading 2';
    TextString='Accuracy, Sensitivity, Specificity and PPV values of various types of classifiers';
    WordText(ActXWord,TextString,Style,[1,0]);%enter after text
  
    [NoRows,NoCols]=size(AB);          
    %create table with data from DataCell
    WordCreateTable(ActXWord,NoRows,NoCols,AB,0);%enter before table
    ActXWord.Selection.InsertBreak;
    
    style='Heading 1';
    text='Analysis Figures';
    WordText(ActXWord,text,style,[0,2]);%enter before and after text

    Style='Heading 2';
    TextString='Clustergram and Heat-map for the selected biomarkers. Note that the expression data are normalized in the range of -2 to 2';
    WordText(ActXWord,TextString,Style,[0,25]);%enter after text
    ActXWord.Selection.GoTo(3,1,45);
    
p=plot(HeatMap(yz,'Standardize',2,'RowLabels',mirbest,'ColumnLabels',R));
fig1=gcf;

fig1.WindowState='maximize';
fig1.ToolBar='auto' ;
    pause(1)

p.FontSize = 22;
figtoprint=figure(1); 
print(figtoprint,'-dmeta'); 
% FigureIntoWord(ActXWord);
%     close(fig1);
invoke(ActXWord.Selection,'Paste');             %paste figure to Word
close Figure 1;
ActXWord.Selection.GoTo(3,1,56);
%  
% Style='Normal';
% TextString='  ';
% WordText(ActXWord,TextString,Style,[0,10]);%enter after text

figure
for s=1:7
plot(xx.p{s},yy.p{s},'-.','LineWidth',2.5)
hold on
end
xlabel('False positive rate'); ylabel('True positive rate');
title('ROC of classification methods');
legend('L1-SVM,RBF','Discriminant Analysis','Classification Tree','Ensemble of 10 tree & adaboost method ','Naive Bayes','Linear Classification','L1-SVM,Linear','Location','Best')
ax = gca;
ax.FontSize = 18;
ax.LineWidth=2;
ax.YLim = [-0.05 1.05];
ax.XLim = [-0.05 1.05];



fig=gcf;

fig.WindowState='fullscreen';
fig.ToolBar='auto' ;
fig.DockControls='on';
figtoprint=figure(1); 
print(figtoprint,'-dmeta'); 
    Style='Heading 2';
    TextString='ROC curve of various type of classifiers';
    WordText(ActXWord,TextString,Style,[0,1]);%enter after text
%     FigureIntoWord(ActXWord);
%     close(fig);
    
invoke(ActXWord.Selection,'Paste');             %paste figure to Word
close Figure 1;
ActXWord.Selection.GoTo(3,1,67)
ActXWord.Selection.InsertBreak;


style='Heading 1';
    text='Meta-Analysis Tables for Second Dataset';
    WordText(ActXWord,text,style,[0,2]);%enter before and after text 
    
    Style='Heading 2';
    TextString='Mean Absolute Error of External/Internal Cross Validation and Classification Edge';
    WordText(ActXWord,TextString,Style,[0,0]);%enter after text
  
    [NoRows,NoCols]=size(AA);          
    %create table with data from DataCell
    WordCreateTable(ActXWord,NoRows,NoCols,AA,1);%enter before table
    
    Style='Heading 2';
    TextString='Selected Biomarkers and their SNR, FDR, mRMR ranking and correlation with classes';
    WordText(ActXWord,TextString,Style,[2,0]);%enter after text
  
    [NoRows,NoCols]=size(Ca);          
    %create table with data from DataCell
    WordCreateTable(ActXWord,NoRows,NoCols,Ca,1);%enter before table
    
    Style='Heading 2';
    TextString='Accuracy, Sensitivity, Specificity and PPV values of various types of classifiers';
    WordText(ActXWord,TextString,Style,[1,0]);%enter after text
  
    [NoRows,NoCols]=size(ABa);          
    %create table with data from DataCell
    WordCreateTable(ActXWord,NoRows,NoCols,ABa,0);%enter before table
    ActXWord.Selection.InsertBreak;
    
    
style='Heading 1';
    text='Meta-Analysis Figures';
    WordText(ActXWord,text,style,[0,2]);%enter before and after text

    Style='Heading 2';
    TextString='Clustergram and Heat-map for the selected biomarkers. Note that the expression data are normalized in the range of -2 to 2';
    WordText(ActXWord,TextString,Style,[0,25]);%enter after text
    ActXWord.Selection.GoTo(3,1,103);
    
p=plot(HeatMap(yz1,'Standardize',2,'RowLabels',gna,'ColumnLabels',R1));
fig1=gcf;

fig1.WindowState='maximize';
fig1.ToolBar='auto' ;
    pause(1)

p.FontSize = 22;
figtoprint=figure(1); 
print(figtoprint,'-dmeta'); 
% FigureIntoWord(ActXWord);
%     close(fig1);
invoke(ActXWord.Selection,'Paste');             %paste figure to Word
close Figure 1;
ActXWord.Selection.GoTo(3,1,114);
%  
% Style='Normal';
% TextString='  ';
% WordText(ActXWord,TextString,Style,[0,10]);%enter after text

figure
for s=1:7
plot(xx1.p{s},yy1.p{s},'-.','LineWidth',2.5)
hold on
end
xlabel('False positive rate'); ylabel('True positive rate');
title('ROC of classification methods');
legend('L1-SVM,RBF','Discriminant Analysis','Classification Tree','Ensemble of 10 tree & adaboost method ','Naive Bayes','Linear Classification','L1-SVM,Linear','Location','Best')
ax = gca;
ax.FontSize = 18;
ax.LineWidth=2;
ax.YLim = [-0.05 1.05];
ax.XLim = [-0.05 1.05];



fig=gcf;

fig.WindowState='fullscreen';
fig.ToolBar='auto' ;
fig.DockControls='on';
figtoprint=figure(1); 
print(figtoprint,'-dmeta'); 
    Style='Heading 2';
    TextString='ROC curve of various type of classifiers';
    WordText(ActXWord,TextString,Style,[0,1]);%enter after text
%     FigureIntoWord(ActXWord);
%     close(fig);
    
invoke(ActXWord.Selection,'Paste');             %paste figure to Word
close Figure 1;
ActXWord.Selection.GoTo(3,1,127)
% ActXWord.Selection.InsertBreak;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%add pagenumbers (0=not on first page)
    WordPageNumbers(ActXWord,'wdAlignPageNumberRight');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
    %Last thing is to replace the Table of Contents so all headings are
    %included.
    %Selection.GoTo What:=wdGoToField, Which:=wdGoToPrevious, Count:=1, Name:= "TOC"
    WordGoTo(ActXWord,7,3,1,'TOC',1);%%last 1 to delete the object
    WordCreateTOC(ActXWord,1,3);

CloseWord(ActXWord,WordHandle,FileSpec);    
    close all;















































































































