            global gna;
            global sol1;
            global D1;
            global R1;
            global tt1;
            global sw1;
            global fw1;
            global ranking1

           [fdr,snr]=fidr(D1,R1);
           sw1=snr(sol1);
           sw1=round(sw1,3);
           fw1=fdr(sol1);
           fw1=round(fw1,3);
           for i=1:size(gna,1)
           tt1(i,1)=find(ranking1==sol1(1,i));
           end
           tt1=tt1(:,1);
           