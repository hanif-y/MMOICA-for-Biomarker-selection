%% MOICA Main Code
% MOICA has been coded in the original version by Zhavat Sherinov et al (Sherinov and �nveren, 2017) and its original MATLAB code is available at the following URL:
%http://www.zhavatsherinov.com/moica.html
%Zhavat SHERINOV and Ahmet �NVEREN, �Multi-objective imperialistic competitive algorithm with multiple non-dominated sets for the solution of global optimization problems�, Soft Computing, Springer, 2017.
%We have modified the original code to obtain a discrete version of the algorithm in order to solve the feature selection problem.
%For correspondence with Hanif Yaghoobi, developer of these codes.
%My email :hanif_yaghoubi@tabrizu.ac.ir

tic;
global myGlob;
myGlob = 0;
global pp;
global Z;
global u;
global kh;
global Empires
global sol
global solc;
global II;
global ND;
global Decade;
global iter;
%% Problem Statement
ProblemParams.CostFuncName = 'MOP18'; % cost function
ProblemParams.CostFuncExtraParams = 1; % change function number according to test problem number in BenchmarkFunction.m file
ProblemParams.NPar = pp; % Number of optimization variables of objective function


ProblemParams.VarMin = 1*ones(1,ProblemParams.NPar);
ProblemParams.VarMax = size(Z,1)*ones(1,ProblemParams.NPar);

    ProblemParams.M =u; % number of objective functions
ProblemParams.SearchSpaceSize = ProblemParams.VarMax - ProblemParams.VarMin;

%% Algorithmic Parameter Setting
AlgorithmParams.NumOfCountries = round(size(Z,1)/pp)+1;% Number of initial countries.
% AlgorithmParams.NumOfCountries = 40;
AlgorithmParams.NumOfInitialImperialists = II;      % Number of Initial Imperialists.
AlgorithmParams.NumOfAllColonies = AlgorithmParams.NumOfCountries - AlgorithmParams.NumOfInitialImperialists;
AlgorithmParams.NumOfDecades = ND;
AlgorithmParams.NumOfFunEvals = 35000;
AlgorithmParams.RevolutionRate = 5;              % Revolution is the process in which the socio-political characteristics of a country change suddenly.
AlgorithmParams.CrossoverRate=10;
AlgorithmParams.Revolutionp = 0.4; 
AlgorithmParams.Crossoverp=0.5;
% AlgorithmParams.UnitingThreshold = 0.02;           % The percent of Search Space Size, which enables the uniting process of two Empires.
AlgorithmParams.UnitingThreshold = 0.1; 
% AlgorithmParams.ImperialistPercentage = 0.3;       % The maximum percent of Imperialists that can be contained in the Empire.
AlgorithmParams.ImperialistPercentage = 0.5; 
%% Creation of Initial Empires
InitialCountries = GenerateNewCountry(AlgorithmParams.NumOfCountries , ProblemParams);

% Calculates the cost of each country. The less the cost is, the more is the power.
InitialCost = feval(ProblemParams.CostFuncName,InitialCountries,ProblemParams.CostFuncExtraParams);

[InitialCost, SortInd] = NonDominationSort(InitialCost,ProblemParams.M); % apply non-domination sorting...
InitialCost = InitialCost(:,1:ProblemParams.M);
InitialCountries = InitialCountries(SortInd,:); % Sort the population with respect to their cost.
Empires = CreateInitialEmpires(InitialCountries,InitialCost,AlgorithmParams, ProblemParams);

Solutions = [];
SolutionPositions = [];
ArchInd = 1;

for Decade = 1:AlgorithmParams.NumOfDecades
    
    for ii = 1:numel(Empires)

        Empires(ii) = AssimilateColonies(Empires(ii),ProblemParams, Empires);
        Empires(ii) = RevolveColonies(Empires(ii),AlgorithmParams,ProblemParams);
 
        %% New Cost Evaluation
        Empires(ii).ColoniesCost = feval(ProblemParams.CostFuncName,Empires(ii).ColoniesPosition,ProblemParams.CostFuncExtraParams);
        %% Empire Possession  (****** Power Possession, Empire Possession) % exchange Imperialist & Best Colony positions if any...
        Empires(ii) = PossesEmpire(Empires(ii), ProblemParams, AlgorithmParams);

        %% Computation of Total Cost for Empires
        empirePop = [Empires(ii).ImperialistCost
                    Empires(ii).ColoniesCost];
        [TotalCosts, ~] = NonDominationSort(empirePop,ProblemParams.M);
        FirstFront =  find(TotalCosts(:,ProblemParams.M+1) == 1);
        Empires(ii).TotalCost = size(FirstFront, 1);
        
    end
    
    %uncomment below line to see the decrease of number of empires in each
    %generation...
    %numberOfEmpires = numel(Empires)
    
    %% Uniting Similiar Empires
    Empires = UniteSimilarEmpires(Empires,AlgorithmParams,ProblemParams);

    %% Imperialistic Competition    
    Empires = ImperialisticCompetition(Empires);
    
    %display number of function evaluations performed...
    FunEvals = myGlob;

    %% Get Non-dominated Solutions
    AllCosts = [];zeros(AlgorithmParams.NumOfCountries, ProblemParams.M);
    AllPositions = [];zeros(AlgorithmParams.NumOfCountries, ProblemParams.NPar);
    AllCostsIndex = 1;
    for u=1:numel(Empires)
        AllCosts(AllCostsIndex:AllCostsIndex + size(Empires(u).ImperialistCost,1) - 1,:) = Empires(u).ImperialistCost;
        AllPositions(AllCostsIndex:AllCostsIndex + size(Empires(u).ImperialistPosition,1) - 1,:) = Empires(u).ImperialistPosition;
        AllCostsIndex = AllCostsIndex + size(Empires(u).ImperialistCost,1);
    end

    tempArr = [];
    tempArrPositions = [];
    tempInd = 1;
    for y=1:size(AllCosts,1)
        if isempty(find(sum(ismember(tempArr,AllCosts(y,:)),2) == ProblemParams.M))
            tempArr(tempInd,:) = AllCosts(y,:);
            tempArrPositions(tempInd, :) = AllPositions(y,:);
            tempInd = tempInd + 1;
        end
    end
    [tempArr, NewIn] = NonDominationSort(tempArr,ProblemParams.M); % apply non-domination sorting...
    
    tempArrPositions = tempArrPositions(NewIn,:);

    Solutions(ArchInd:ArchInd+size(tempArr(find(tempArr(:,ProblemParams.M+1) == 1),1:ProblemParams.M),1)-1,:) = tempArr(find(tempArr(:,ProblemParams.M+1) == 1),1:ProblemParams.M);
    SolutionPositions(ArchInd:ArchInd+size(tempArr(find(tempArr(:,ProblemParams.M+1) == 1),1:ProblemParams.M),1)-1,:) = tempArrPositions(1:size(tempArr(find(tempArr(:,ProblemParams.M+1) == 1),1:ProblemParams.M),1),:);
    ArchInd = ArchInd + size(tempArr(find(tempArr(:,ProblemParams.M+1) == 1),1:ProblemParams.M),1);
   
    % Terminate if Max Fun Evals reached...
    if myGlob > AlgorithmParams.NumOfFunEvals
        break;
    end
iter=Decade   
Empires(1).ImperialistCost
% cost(Decade,:)=min(Empires(1).ImperialistCost);
% SearchProgressEditFieldValueChanged(app1,iter)
end % End of Algorithm

Solutions = [SolutionPositions Solutions];
[Solutions, I] = unique(Solutions, 'rows');
%Solutions = Get_Non_Dominated_Solutions(Solutions,ProblemParams.M);
% [Solutions, ~] = NonDominationSort(Solutions,ProblemParams.M);
% Solutions = Solutions(find(Solutions(:,end-1) == 1),ProblemParams.NPar+1:ProblemParams.NPar + ProblemParams.M);

% dlmwrite('Solutions',Solutions,'delimiter','\t','precision', '%.12f');
sol=Empires.ImperialistPosition;
solc=Empires.ImperialistCost;
f = Solutions;
% if ProblemParams.M == 2
%     uf = load('ZDT4.pf');
%     plot(uf(:,1),uf(:,2),'r*');
%     hold on;        
%     plot(Solutions(:,1),Solutions(:,2),'*');
%     title('MOICA Two Functions');
%     xlabel('f(x_1)');
%     ylabel('f(x_2)');
% else
%     uf = load('UF10.pf');
%     plot3(uf(:,1),uf(:,2),uf(:,3),'r*');
%     hold on;
%     plot3(Solutions(:,1),Solutions(:,2),Solutions(:,3),'*');
%     title('MOICA Three Functions');
%     xlabel('f(x_1)');
%     ylabel('f(x_2)');
%     zlabel('f(x_3)');
% end
% end