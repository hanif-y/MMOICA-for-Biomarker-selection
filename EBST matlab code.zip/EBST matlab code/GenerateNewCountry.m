%% Generates new countries randomly
function NewCountry = GenerateNewCountry(NumOfCountries,ProblemParams)
%     VarMinMatrix = repmat(ProblemParams.VarMin,NumOfCountries,1);
%     VarMaxMatrix = repmat(ProblemParams.VarMax,NumOfCountries,1);
%     NewCountry = (VarMaxMatrix - VarMinMatrix) .* rand(size(VarMinMatrix)) + VarMinMatrix;
t=ProblemParams.VarMin:ProblemParams.VarMax;
for i=1:NumOfCountries
   nn=randi(size(t,2),[ProblemParams.NPar 1])';
   NewCountry(i,:)=t(nn);
   t(nn)=0;
   t=find(t~=0); 
end
%     NewCountry =randi(ProblemParams.VarMax(1,1),[ProblemParams.NPar size(VarMinMatrix,1)])';
end