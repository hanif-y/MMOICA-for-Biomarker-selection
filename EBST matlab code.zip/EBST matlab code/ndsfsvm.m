function [Dfo,Dff,indo2,indf2,Scost]=ndsfsvm(D,L,indo,indf)
global Z;
global R;
global s;
s=5;
Z=D;
R=L;
q=(1:size(D,1))';
zzz=MOP14(q,1);
[Scost, indo1] = NonDominationSort(zzz,size(zzz,2));
indf1=indo1(1:(size(indo1,1)/2+1),:);
indf2=indf(indf1);
indo2=indo(indo1);
Dfo=D(indo1,:);
Dff=D(indf1,:);
