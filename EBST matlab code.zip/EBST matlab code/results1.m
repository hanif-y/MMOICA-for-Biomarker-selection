global yz;
global value5;
global mirbest;
global xx;
global yy;
global R;
f2(app4);
f3(app3);
G1=clustergram(yz,'Standardize',2,'cluster',value5);
set(G1,'RowLabels',mirbest,'ColumnLabels',R,'Dendrogram',2);
figure
for s=1:7
plot(xx.p{s},yy.p{s},'-.','LineWidth',2.5)
hold on
end
xlabel('False positive rate'); ylabel('True positive rate');
title('ROC of classification methods');
legend('L1-SVM,RBF','Discriminant Analysis','Classification Tree','Ensemble of 10 tree & adaboost method ','Naive Bayes','Linear Classification','L1-SVM,Linear','Location','Best')
ax = gca;
ax.FontSize = 18;
ax.LineWidth=2;
ax.YLim = [-0.05 1.05];
ax.XLim = [-0.05 1.05];