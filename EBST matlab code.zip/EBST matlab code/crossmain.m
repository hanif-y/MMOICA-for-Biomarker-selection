%This function calculates the performance metrics derived from the confusion matrix 
%and classification error for the input variables. 
%input : 
% D = original data with all variables
% L = class lable matrix 
% RF = selected variables index matrix
%output :
% zzz = [external mae,internal mae,-1* classification edge]
% t = [external accuracy,internal accuracy,mean of external accuracy,sensitivity,specificity,PPV]
% xx = false positive rate
% yy = true positive rate
% AUC = AUC of ROC
% Note that all output variables are obtained in an average of k-fold cross-validation .
function [zzz,t,xx,yy,AUC]=crossmain(D,L,RF,ss)
% global Z;
% global R;
% global ranking;
% global indf;
% global s;
% s=ss;
% Z=D;
[zzz,t,xx,yy,AUC]=MOP15(RF,D,L,ss);

