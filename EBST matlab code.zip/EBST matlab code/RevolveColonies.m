%% Revolution
% Revolution is a process where colonies are revolved with respect to their
% local imperialist selected randomly from the set of local non-dominated
% solution set.
function TheEmpire = RevolveColonies(TheEmpire,AlgorithmParams,ProblemParams)
if rand() < AlgorithmParams.Crossoverp
% NumOfRevolvingColonies = size(TheEmpire.ColoniesCost,1);
    for ii=1:AlgorithmParams.CrossoverRate
        P1 = randi(size(TheEmpire.ColoniesCost,1), 1);
        ks=unidrnd(ProblemParams.NPar,[1 round(ProblemParams.NPar/2)]);
        parent_1 = TheEmpire.ColoniesPosition(P1,ks);
        

            P2 = randi(size(TheEmpire.ColoniesCost,1), 1);
            while P1 == P2&&P1~=1&&P2~=1
                P2 = randi(size(TheEmpire.ColoniesCost,1), 1);
            end
            parent_2 = TheEmpire.ColoniesPosition(P2,ks);
            
           TheEmpire.ColoniesPosition(P1,ks) = parent_2;
           TheEmpire.ColoniesPosition(P2,ks) = parent_1; 
           
    end
end   
if rand()< AlgorithmParams.Revolutionp
NumOfRevolvingColonies = size(TheEmpire.ColoniesCost,1);
    t=ProblemParams.VarMin:ProblemParams.VarMax;
    for i=1:AlgorithmParams.RevolutionRate
    nn=randi(size(t,2),[ProblemParams.NPar 1])';
    NewCountry=t(nn);
    P3 = randi(size(TheEmpire.ColoniesCost,1), 1);
%     while P3 == P2||P3==P1
%                 P3 = randi(size(TheEmpire.ColoniesCost,1), 1);
%     end
        ks=unidrnd(ProblemParams.NPar,[1 round(ProblemParams.NPar/2)]);
     TheEmpire.ColoniesPosition(P3,ks) =NewCountry(1,ks) ;   
    end
   nn=randi(size(t,2),[ProblemParams.NPar 1])';
   NewCountry=t(nn);
   if NumOfRevolvingColonies>=6
   TheEmpire.ColoniesPosition(end,:) =NewCountry;
   end
   if NumOfRevolvingColonies<6
   TheEmpire.ColoniesPosition(end+1,:) =NewCountry;
   end
  end
end


