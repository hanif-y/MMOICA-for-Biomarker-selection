%SNR and FDR ranking of selected variables (Bestfreq1)
global tt;
global sw;
global fw;
global D;
global R;
global Bestfreq1;
global ranking;
[fdr,snr]=fidr(D,R);
sw=snr(Bestfreq1);
sw=round(sw,3);
fw=fdr(Bestfreq1);
fw=round(fw,3);
for i=1:size(mirbest,1)
tt(i,1)=find(ranking==Bestfreq1(1,i));
end
tt=tt(:,1);