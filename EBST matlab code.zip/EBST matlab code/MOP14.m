% Objective Function 1
%input : 
% D = original data with all variables
% L = class lable matrix 
% RF = selected variables index matrix
%output :
% zzz = [external mae,internal mae,-1* classification edge]
% t = [external accuracy,internal accuracy,mean of external accuracy,sensitivity,specificity,PPV]
% xx = false positive rate
% yy = true positive rate
% AUC = AUC of ROC
% Note that all output variables are obtained in an average of k-fold cross-validation .


function z=MOP14(x,~)
global myGlob;
global Z;
global R;
global s;
% global ranking;
global indf;
[a , ~]=size(x);
tic
for k=1:a
    indices = crossvalind('Kfold',R,10);
for ii=1:10
   test = (indices == ii); train2 = ~test;
y=Z(x(k,:),train2);
t=Z(x(k,:),test);
Y=R(:,train2);
e=R(:,test);
indices1 = crossvalind('Kfold',Y,5);
switch s
    case 1
nn1 = fitcsvm(y',Y','Standardize',false,'KernelFunction','rbf');
    case 2
nn1=fitcdiscr(y',Y');
    case 3
nn1=fitctree(y',Y');
    case 4       
nn1 = fitensemble(y',Y','AdaBoostM1',10,'Tree');
    case 5
nn1 = fitcsvm(y',Y','Standardize',true,'KernelFunction','polynomial');  
    case 6
tt = templateSVM('Standardize',1,'KernelFunction','gaussian');
nn1 = fitcecoc(y',Y','Learners',tt);
    case 7
nn1=fitcnb(y',Y'); 
    case 8
nn1=fitclinear(y',Y'); 
    case 9
nn1 = fitensemble(y',Y','AdaBoostM1',50,'Discriminant');        
end
for kk=1:5
test1 = (indices1 == kk); train1 = ~test1;
y1=y(:,train1);
t1=y(:,test1);
Y1=Y(:,train1);
e1=Y(:,test1);
label3 = predict(nn1,t1');
zz3(kk)=sum(~eq(label3,e1'));
L(kk) = loss(nn1,y1',Y1');
end
label1 = predict(nn1,t');
zz1(ii)=sum(~eq(label1,e'));
ed(ii) =edge(nn1,t',e');
zz6(ii)=loss(nn1,y',Y');
zz2(ii)=mean(sum(zz3));
zz4(ii)=mean(sum(L));
predp=label1(label1==1);
tcp=e(label1==1)';
tp=sum(eq(predp,tcp));
predn=label1(label1==0);
tcn=e(label1==0)';
fn=sum(~eq(predn,tcn));
zz7(ii)=1-(tp./(tp+fn));
end

z3(1,k)=mean(zz1);
z4(1,k)=mean(zz2);
z5(1,k)=mean(zz6);
z6(1,k)=mean(sum(zz4));
z7(1,k)=mean(zz7);
z9(1,k)=-1*mean(ed);
% for u=1:size(x(k,:),2)
%     q(u)=find(ranking==indf(x(k,u)));
% end
% z8(1,k)=mean(q)/size(Z,1);
end
toc
z=[z3;z4;z7;z9]';
myGlob = myGlob + size(x,1);