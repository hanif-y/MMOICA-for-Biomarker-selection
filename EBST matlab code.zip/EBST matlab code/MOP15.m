% Objective Function 2
%input : 
% D = original data with all variables
% L = class lable matrix 
% RF = selected variables index matrix
%output :
% zzz = [external mae,internal mae,-1* classification edge]
% t = [external accuracy,internal accuracy,mean of external accuracy,sensitivity,specificity,PPV]
% xx = false positive rate
% yy = true positive rate
% AUC = AUC of ROC
% Note that all output variables are obtained in an average of k-fold cross-validation .

function [z,t,xx,yy,AUC]=MOP15(x,Z,R,s)
global myGlob;
% global Z;
% global R;
% global s;
global kfold
global stan
% ww=round(size(R,2)/(kfold));
% xx1=[];
% yy1=[];

[a , ~]=size(x);
tic
for k=1:a
    indices = crossvalind('Kfold',R,kfold);
    for i=1:kfold
    v(i,1)=size(find(indices==i),1);
    end
    ww=min(v);
for ii=1:kfold
   test = (indices == ii); train2 = ~test;
y=Z(x(k,:),train2);
t=Z(x(k,:),test);
Y=R(:,train2);
e=R(:,test);
indices1 = crossvalind('Kfold',Y,5);
switch s
    case 1
nn1 = fitcsvm(y',Y','Standardize',stan,'KernelFunction','rbf');
% nn1 = fitPosterior(nn1);
    case 2
nn1=fitcdiscr(y',Y');
    case 3
nn1=fitctree(y',Y');
    case 4       
nn1 = fitensemble(y',Y','AdaBoostM1',10,'Tree');
%     case 5
% nn1 = fitcsvm(y',Y','Standardize',false,'KernelFunction','polynomial');  
%     case 6
% tt = templateSVM('Standardize',1,'KernelFunction','gaussian');
% nn1 = fitcecoc(y',Y','Learners',tt);
    case 5
nn1=fitcnb(y',Y'); 
    case 6
nn1=fitclinear(y',Y'); 
    case 7
nn1 = fitcsvm(y',Y','Standardize',stan,'KernelFunction','linear');
%     case 9
% nn1 = fitensemble(y',Y','AdaBoostM1',50,'Discriminant');        
end
for kk=1:5
test1 = (indices1 == kk); train1 = ~test1;
y1=y(:,train1);
t1=y(:,test1);
Y1=Y(:,train1);
e1=Y(:,test1);
label3 = predict(nn1,t1');
zz3(kk)=sum(~eq(label3,e1'));
L(kk) = loss(nn1,y1',Y1');
end
[label1,score] = predict(nn1,t');
zz1(ii)=sum(~eq(label1,e'));
ed(ii) =edge(nn1,t',e');
zz6(ii)=loss(nn1,y',Y');
zz2(ii)=mean((zz3));
zz4(ii)=mean(sum(L));
predp=label1(label1==1);
tcp=e(label1==1)';
tp=sum(eq(predp,tcp));
fp=sum(~eq(predp,tcp));
predn=label1(label1==0);
tcn=e(label1==0)';
fn=sum(~eq(predn,tcn));
tn=sum(eq(predn,tcn));
zz7(ii)=(tp./(tp+fn));
zz8(ii)=(tn./(fp+tn));
zz10(ii)=(tp./(tp+fp));
zz11(ii)=((tp+tn)./(tp+tn+fp+fn));
if s==3||s==4||s==5
[dx1,dy1,~,zz14(ii,:)]=perfcurve(e(1,1:ww)',score(1:ww,2),1);
r1(1,ii)=size(dx1,1);
r2(1,ii)=size(dy1,1);
if ii==1
xx1(ii,:)=dx1(1:r1(1,ii),1)';
yy1(ii,:)=dy1(1:r1(1,ii),1)';
end
if ii>=2
if r1(1,ii)>r1(1,ii-1)
xx1(ii,1:r1(1,ii-1))=dx1(1:r1(ii-1),1)';
yy1(ii,1:r1(1,ii-1))=dy1(1:r1(ii-1),1)';
end
if r1(1,ii)<=r1(1,ii-1)
xx1(ii,1:r1(1,ii))=dx1(1:r1(ii),1)';
yy1(ii,1:r1(1,ii))=dy1(1:r1(ii),1)';

end
end
else
[dx1,dy1,~,zz14(ii,:)]=perfcurve(e(1,1:ww)',score(1:ww,2),1);
r1(1,ii)=size(dx1,1);
r2(1,ii)=size(dy1,1);
if ii==1
xx1(ii,:)=dx1(1:r1(1,ii),1);
yy1(ii,:)=dy1(1:r1(1,ii),1);
end
if ii>=2
if r1(1,ii)>r1(1,ii-1)
xx1(ii,1:r1(1,ii-1))=dx1(1:r1(ii-1),1);
yy1(ii,1:r1(1,ii-1))=dy1(1:r1(ii-1),1);
end
if r1(1,ii)<=r1(1,ii-1)
xx1(ii,1:r1(1,ii))=dx1(1:r1(ii),1);
yy1(ii,1:r1(1,ii))=dy1(1:r1(ii),1);

end
end  
% [xx1(ii,:),yy1(ii,:),~,zz14(ii,:)]=perfcurve(e(1,1:ww)',score(1:ww,2),1);    
end
zz12(ii,:)=score(1:ww,2)';
end

z3(1,k)=mean(zz1);
z4(1,k)=mean(zz2);
z5(1,k)=mean(zz6);
z6(1,k)=mean(sum(zz4));
se(1,k)=mean(zz7);
sp(1,k)=mean(zz8);
ppv(1,k)=mean(zz10);
acc(1,k)=mean(zz11);
z9(1,k)=-1*mean(ed);
% [aa,~]=find(min(zz14));
% sc=zz12(aa,:);
% [xx(k,:),yy(k,:),~,~] =perfcurve(e(1,1:ww),sc(1,1:ww),1);
% sc=[];
if s==3||s==4||s==5
xx(k,:)=sort(max(xx1));
yy(k,:)=sort(max(yy1));

else
xx(k,:)=sort(mean(xx1));
yy(k,:)=sort(mean(yy1)); 

end
% AUC(k,:)=mean(zz14);
AUC(k,:) = trapz(xx(k,:),yy(k,:));
% ll(k,:)=mean(zz13);

% for u=1:size(x(k,:),2)
%     q(u)=find(ranking==indf(x(k,u)));
% end
% z8(1,k)=mean(q)/885;
end
mb1=numel(R);
a1=numel(find(test==1));
a2=numel(find(test1==1));
eacc=(a1-z3)/a1;
iacc=(a2-z4)/a2;

z=[z3;z4;z9]';
t=[eacc iacc acc se sp ppv];

myGlob = myGlob + size(x,1);