global v
global vpmc6;
global vncbi6;
yaz=Ca(v.Indices(1,1),v.Indices(1,2));
for j=2:size(v.Indices,1)
yaz=[yaz Ca(v.Indices(j,1),v.Indices(j,2))];
end
a1=char(yaz(1,1));
for j=2:size(yaz,2)
a1=[a1,'+',char(yaz(1,j))];
end
if vpmc6==1
url = ['https://www.ncbi.nlm.nih.gov/pmc/?term=',a1];
web(url)
end
if vncbi6==1
url = ['https://www.ncbi.nlm.nih.gov/search/all/?term=',a1];
web(url) 
end