function y=repeatf(x)
[a,b]=size(x);
for i=1:b
    g=find(x==x(:,i));
    s(1,g(1,1))=x(:,i);
end
k=0;
for j=1:size(s,2)
    if s(1,j)~=0
        k=k+1;
      y(1,k)=s(1,j);
    end
end