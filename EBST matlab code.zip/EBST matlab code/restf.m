global Z;
global R;
global indf;
global ranking
global idn
global sol
global solc;
global D;
global mirbest;
global Bestfreq1;
global kkk;
global value5;
global yz;
global che;
global G1;
BestSol.Position=[];
fla=[];
mir={};
B=[];
index=[];
index1=[];
indexx=[];
Bestfreq=[];
BestSol.Position=indf(sol);
zzz=[];
Bestfreq1=[];
qq=[];
qq1=[];
fla1=[];
mirbest={};

prn=(1:100000)';
for ll=1:size(BestSol.Position,1)
fla(ll,:)=prn(BestSol.Position(ll,:),:);
for i=1:size(BestSol.Position,2)
%     mir(ll,i)=idn(find(strcmp(idn(:,2),fla(ll,i))));
mir(ll,i)=idn(fla(ll,i),1);
end
end
k=0;
[B,index]=sortrows(solc,1);
[B,index1]=sortrows(B,2);
indexx=index(index1);
for i=indexx(1:kkk,:)'
    k=k+1;
qq=(sol(i,:));
Bestfreq.p{k}=repeatf(qq);
% yz=Z(Bestfreq.p{k},:);
zzz(k,:)=MOP18(Bestfreq.p{k},1);
qq=(BestSol.Position(i,:));
Bestfreq.q{k}=repeatf(qq);

end
% qq1=[Bestfreq.q{1} Bestfreq.q{2} Bestfreq.q{3}];
qq1=[Bestfreq.q{1}];
if kkk>=2
for jjj=2:kkk
    qq1=[qq1 Bestfreq.q{jjj}];
end
end
Bestfreq1=repeatf(qq1);

fla1=prn(Bestfreq1,:);
for i=1:size(Bestfreq1,2)
%     mirbest(i,:)=idn(find(strcmp(idn(:,2),fla1(i))));

mirbest(i,:)=idn(fla1(i),1);
end
yz=D(Bestfreq1,:);
if che==1
G1=clustergram(yz,'Standardize',2,'cluster',value5);
set(G1,'RowLabels',mirbest,'ColumnLabels',R,'Dendrogram',2);
end

