
global AA;
global Ca;
global ABa;
[file,path] = uiputfile;
filename = [path,file];
sheet = 1;

xlRange = 'A1';
xlswrite(filename,AA,sheet,xlRange);

xlRange = 'A1';
sheet = 2;
xlswrite(filename,Ca,sheet,xlRange);

xlRange = 'A1';
sheet = 3;
xlswrite(filename,ABa,sheet,xlRange);