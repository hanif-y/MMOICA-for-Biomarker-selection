%% Imperialistic Competition
% Imperialistic competiton is a process in which weakest colony (i.e. a colony with
% the worst cost) in a weakest empire (i.e. an empire with the worst cost)
% is given to the stronger empires with better costs. This happens based on
% the probability. Therefore, more powerful the empire is (i.e. an empire
% with better cost than others) the more chances it has to posses the
% weakest colony in the weakest empire.
function Empires=ImperialisticCompetition(Empires)
    if rand > .11 
        return
    end
    if numel(Empires)<=1
        return;
    end

    TotalPowers = [Empires.TotalCost];
    [~, WeakestEmpireInd] = min(TotalPowers);
    WeakestEmpireInd = WeakestEmpireInd(1);
    PossessionProbability = TotalPowers / sum(TotalPowers);
    
    SelectedEmpireInd = SelectAnEmpire(PossessionProbability);
    
    nn = size((Empires(WeakestEmpireInd).ColoniesCost),1);
    
    if(nn == 0)
        Empires(SelectedEmpireInd).ColoniesPosition = [Empires(SelectedEmpireInd).ColoniesPosition
                                                       Empires(WeakestEmpireInd).ImperialistPosition];
                                                   
        Empires(SelectedEmpireInd).ColoniesCost = [Empires(SelectedEmpireInd).ColoniesCost
                                                   Empires(WeakestEmpireInd).ImperialistCost];
        Empires=Empires([1:WeakestEmpireInd-1 WeakestEmpireInd+1:end]);
    else
        jj = randi(nn,1);

        Empires(SelectedEmpireInd).ColoniesPosition = [Empires(SelectedEmpireInd).ColoniesPosition
                                                       Empires(WeakestEmpireInd).ColoniesPosition(jj,:)];

        Empires(SelectedEmpireInd).ColoniesCost = [Empires(SelectedEmpireInd).ColoniesCost
                                                   Empires(WeakestEmpireInd).ColoniesCost(jj,:)];

        Empires(WeakestEmpireInd).ColoniesPosition = Empires(WeakestEmpireInd).ColoniesPosition([1:jj-1 jj+1:end],:);
        Empires(WeakestEmpireInd).ColoniesCost = Empires(WeakestEmpireInd).ColoniesCost([1:jj-1 jj+1:end],:);

        
        %% Collapse of the weakest colony-less Empire
        nn = numel(Empires(WeakestEmpireInd).ColoniesCost);
        if nn<=1
            Empires(SelectedEmpireInd).ColoniesPosition = [Empires(SelectedEmpireInd).ColoniesPosition
                                                           Empires(WeakestEmpireInd).ImperialistPosition
                                                           Empires(WeakestEmpireInd).ColoniesPosition
                                                           ];
            Empires(SelectedEmpireInd).ColoniesCost = [Empires(SelectedEmpireInd).ColoniesCost
                                                       Empires(WeakestEmpireInd).ImperialistCost
                                                       Empires(WeakestEmpireInd).ColoniesCost];
            Empires=Empires([1:WeakestEmpireInd-1 WeakestEmpireInd+1:end]);
        end
    end


end

function Index = SelectAnEmpire(Probability)
    R = rand(size(Probability));
    D = Probability - R;
    [MaxD Index] = max(D);
end
