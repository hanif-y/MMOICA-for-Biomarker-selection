global e11;
global e22;
global tt1;
global sw1;
global fw1;
global AUC1;
global gna;
global posclass1;
global negclass1;
global AA;
global Ca;
global ABa;
Ca={};
ABa={};
e11=round(e11,4);
e22=round(e22,4);
e11(:,3)=-e11(:,3);
Aa(1,:)={'E.C.V MAE','I.C.V MAE','C.E'};
% Aa(2:size(e11,1)+1,:)=num2cell(e11);
for t=1:size(e11,1)
for u=1:size(e11,2)
Aa{t+1,u}=num2str(e11(t,u));
end
end
AAa={'Classifier Type';'l1-SVM RBF Kernel'	;'LDA'	;'C-Tree'	;'Ensemble 10 Tree';	'Na�ve-Bayes';	'Linear';	'l1-SVM Linear Kernel'};
AA=[AAa Aa];
Ca(1,:)={'Selected miRNA'	,'Class Correlation'	,'SNR',	'FDR',	'mRMR Ranking'};
Ca(2:size(gna,1)+1,1)=gna;

% Ca(2:size(gna,1)+1,5)=num2cell(tt1);
for t=1:size(tt1,1)

Ca{t+1,5}=num2str(tt1(t,1));
end

% Ca(2:size(gna,1)+1,3)=num2cell(sw1);
for t=1:size(sw1,1)

Ca{t+1,3}=num2str(sw1(t,1));
end

% Ca(2:size(gna,1)+1,4)=num2cell(fw1);
for t=1:size(fw1,1)

Ca{t+1,4}=num2str(fw1(t,1));
end

for j=1:size(gna,1)
if sw1(j,1)>=0
cca(j,1)={negclass1};
end
if sw1(j,1)<=0
cca(j,1)={posclass1};
end
end
Ca(2:size(gna,1)+1,2)=cca;

ABa(2,:)={'','l1-SVM RBF Kernel'	,'LDA','C-Tree','Ensemble 10 Tree','Na�ve-Bayes','Linear','l1-SVM Linear Kernel'};
ABa(3:7,1)={'Acc'; 'Se'; 'Sp'; 'PPV'; 'AUC'};

% ABa(3:6,2:size(e22,1)+1)=num2cell(e22(:,3:end)');
for t=3:6
for u=2:size(e22,1)+1
ABa{t,u}=num2str(e22(u-1,t));
end
end

% ABa(7,2:size(e22,1)+1)=num2cell(AUC1');
for u=2:size(e22,1)+1
ABa{7,u}=num2str(AUC1(u-1,1));
end
for t=1:4
ABa{1,t}='';
end
for t=6:8
ABa{1,t}='';
end
ABa{2,1}='';
ABa(1,5)={'Classifier Type'};
