function [d,r,id,z,ran,indf]=prepross(d,r,id)         
            global v1;
            global v2;
            
            global tr;

            global snrf;
            global fdr;
            global snr;
            global indo;
            global fdrf;
            global Sd;
            global value1;
            global value2;
            global value3;
            global vallog10;
            global vallog2;
            global valth;
            global valthmax;
            global valthmin;
            global varfil;
            global enfil;
            global ranfil;
            global lvalfil;





            if valth==1
                for i=1:size(d,1)
                    for j=1:size(d,2)
                        if d(i,j)>=valthmax
                            d(i,j)=valthmax;
                        end
                        if d(i,j)<=valthmin
                            d(i,j)=valthmin;
                        end
                    end
                end
            end
            if varfil==1
                [~,d,id] = genevarfilter(d,id);
            end
            if enfil==1
                [~,d,id] = geneentropyfilter(d,id);
            end
            if ranfil==1
                [~,d,id] = generangefilter(d,id);
            end
            if lvalfil==1
                [~,d,id] = genelowvalfilter(d,id);
            end
            
            if vallog10==1
               d=log10(d);
           end
           if vallog2==1
               d=log2(d);
           end
            
            if value1==1
            d=zscore(d);
            end
            
            if value2==1
          
            a=zscore(d');
            d=a';
            end
            
            if value3==1
           
            a1=sum(r==0);
            a2=sum(r==1);
            if a1<=a2
            w=r==1;
            w1=r==0;
            h=r(1,w);
            h1=d(:,w);
            q=randi(sum(w),[1 sum(w1)]);
            h=h(1,q);
            h1=h1(:,q);
            d=[d(:,w1) h1];
            r=[r(1,w1) h];
            end
            if a1>a2
            w=r==1;
            w1=r==0;
            h=r(1,w1);
            h1=d(:,w1);
            q=randi(sum(w1),[1 sum(w)]);
            h=h(1,q);
            h1=h1(:,q);
            d=[h1 d(:,w)];
            r=[h r(1,w)];
            end
            end
            
            if v1==1
                [fdr,snr,indo,indf,snrf,fdrf,Sd,z]=fidrf(d,r,tr);
            else
                [fdr,snr,indo,indf,snrf,fdrf,Sd,z]=fidrf(d,r,0);
            end
            if v2==1
                nf=size(z,1);
                ran = indf(mRMR(z', (r'*2-1), nf));
            else
                ran=indf;
            end
          