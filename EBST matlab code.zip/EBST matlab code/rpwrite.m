global AB;
global C;
global A;
[file,path] = uiputfile;
filename = [path,file];
sheet = 1;
xlRange = 'A1';
xlswrite(filename,A,sheet,xlRange);

xlRange = 'A1';
sheet = 2;
xlswrite(filename,C,sheet,xlRange);


xlRange = 'A1';
sheet = 3;
xlswrite(filename,AB,sheet,xlRange);