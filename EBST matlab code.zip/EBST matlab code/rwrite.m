global e1;
global e2;
global tt;
global sw;
global fw;
global AUC;
global mirbest;

global AB;
global C;
global A;
global posclass;
global negclass;
C={};
AB={};
e1=round(e1,4);
e2=round(e2,4);
e1(:,3)=-e1(:,3);
A1(1,:)={'E.C.V MAE','I.C.V MAE','C.E'};
% A1(2:size(e1,1)+1,:)=num2cell(e1);
for t=1:size(e1,1)
for u=1:size(e1,2)
A1{t+1,u}=num2str(e1(t,u));
end
end
 
AA1={'Classifier Type';'l1-SVM RBF Kernel'	;'LDA'	;'C-Tree'	;'Ensemble 10 Tree';	'Na�ve-Bayes';	'Linear';	'l1-SVM Linear Kernel'};
A=[AA1 A1];

C(1,:)={'Selected Biomarkers'	,'Class Correlation'	,'SNR',	'FDR',	'mRMR Ranking'};
C(2:size(mirbest,1)+1,1)=mirbest;


snrrank;
% C(2:size(mirbest,1)+1,5)=num2str(tt);
for t=1:size(tt,1)

C{t+1,5}=num2str(tt(t,1));
end
 
% C(2:size(mirbest,1)+1,3)=num2cell(sw);
for t=1:size(sw,1)

C{t+1,3}=num2str(sw(t,1));
end

% C(2:size(mirbest,1)+1,4)=num2cell(fw);
for t=1:size(fw,1)

C{t+1,4}=num2str(fw(t,1));
end

for j=1:size(mirbest,1)
if sw(j,1)>=0
cc(j,1)={negclass};
end
if sw(j,1)<=0
cc(j,1)={posclass};
end
end
C(2:size(mirbest,1)+1,2)=cc;

AB(2,:)={'','l1-SVM RBF Kernel'	,'LDA','C-Tree','Ensemble 10 Tree','Na�ve-Bayes','Linear','l1-SVM Linear Kernel'};
AB(3:7,1)={'Acc'; 'Se'; 'Sp'; 'PPV'; 'AUC'};

% AB(3:6,2:size(e2,1)+1)=num2cell(e2(:,3:end)');
for t=3:6
for u=2:size(e2,1)+1
AB{t,u}=num2str(e2(u-1,t));
end
end

% AB(7,2:size(e2,1)+1)=num2cell(AUC');

for u=2:size(e2,1)+1
AB{7,u}=num2str(AUC(u-1,1));
end
for t=1:4
AB{1,t}='';
end
for t=6:8
AB{1,t}='';
end
AB{2,1}='';
AB(1,5)={'Classifier Type'};
