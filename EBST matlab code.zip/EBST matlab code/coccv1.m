% ROC Curve Plot for L1-SVM,Discriminant Analysis,Classification Tree,Ensemble of 10 tree & adaboost method,Naive Bayes,Linear Classification
global e11;
global e22;
global xx1;
global yy1;
global AUC1;
global sol1;
global D1;
global R1;
xx1={};
yy1={};
e11=[];
e22=[];
AUC1=[];
figure
for s=1:7
[e11(s,:),e22(s,:),xxz.p{s},yyz.p{s},AUC1(s,:)]=crossmain(D1,R1,sol1,s);
qx = 1:1/100:size(xxz.p{s},2);
xx1.p{s} = interp1(round(xxz.p{s},2),qx,'pchip');
yy1.p{s} = interp1(round(yyz.p{s},2),qx,'pchip');

plot(xx1.p{s},yy1.p{s},'-.','LineWidth',2.5)
hold on
end
xlabel('False positive rate'); ylabel('True positive rate');
title('ROC of classification methods');
legend('L1-SVM,RBF','Discriminant Analysis','Classification Tree','Ensemble of 10 tree & adaboost method ','Naive Bayes','Linear Classification','L1-SVM,Linear','Location','Best')
ax = gca;
ax.FontSize = 18;
ax.LineWidth=2;
ax.YLim = [-0.05 1.05];
ax.XLim = [-0.05 1.05];