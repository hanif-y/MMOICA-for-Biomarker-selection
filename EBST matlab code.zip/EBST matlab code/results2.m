global yz1;
global value5;
global R1;
global gna;
global xx1;
global yy1;
f3(app6);
f2(app7);
G1=clustergram(yz1,'Standardize',2,'cluster',value5);
           set(G1,'RowLabels',gna,'ColumnLabels',R1,'Dendrogram',2);
           
figure
for s=1:7
plot(xx1.p{s},yy1.p{s},'-.','LineWidth',2.5)
hold on
end
xlabel('False positive rate'); ylabel('True positive rate');
title('ROC of classification methods');
legend('L1-SVM,RBF','Discriminant Analysis','Classification Tree','Ensemble of 10 tree & adaboost method ','Naive Bayes','Linear Classification','L1-SVM,Linear','Location','Best')
ax = gca;
ax.FontSize = 18;
ax.LineWidth=2;
ax.YLim = [-0.05 1.05];
ax.XLim = [-0.05 1.05];