 global classname;
   global gseData;      
         global rows;   
         global Ra;
global w;


         
          switch w
              case 'title'
          Ra=gseData.Header.Samples.title(rows,:);
              case 'status'
              Ra=gseData.Header.Samples.status(rows,:);    
              case 'type'
               Ra=gseData.Header.Samples.type(rows,:);   
              case 'channel_count'
              Ra=gseData.Header.Samples.channel_count(rows,:);    
              case 'source_name_ch1'
               Ra=gseData.Header.Samples.source_name_ch1(rows,:);      
              case 'organism_ch1'
               Ra=gseData.Header.Samples.organism_ch1(rows,:);   
              case 'characteristics_ch1'
              Ra=gseData.Header.Samples.characteristics_ch1(rows,:);    
              case 'molecule_ch1'
               Ra=gseData.Header.Samples.molecule_ch1(rows,:);   
              case 'description'
               Ra=gseData.Header.Samples.description(rows,:);   
          end
classname={};
a1=strcmp(Ra(1,:),Ra(1,1));
ra1=Ra(1,~a1);
classname(1)=Ra(1,1);
k=1;
while ~isempty(ra1)
    k=k+1;
classname(k)=ra1(1,1);    
a1=strcmp(ra1(1,:),ra1(1,1));
ra1=ra1(1,~a1);
end