% ROC Curve Plot for L1-SVM,Discriminant Analysis,Classification Tree,Ensemble of 10 tree & adaboost method,Naive Bayes,Linear Classification
global e1;
global e2;
global xx;
global yy;
global AUC;
global Bestfreq1;
global D;
global R;
global roc;
if roc==1
figure
end
for s=1:7
[e1(s,:),e2(s,:),xxz.p{s},yyz.p{s},AUC(s,:)]=crossmain(D,R,Bestfreq1,s);
qx = 1:1/100:size(xxz.p{s},2);
xx.p{s} = interp1(round(xxz.p{s},2),qx,'pchip');
yy.p{s} = interp1(round(yyz.p{s},2),qx,'pchip');
if roc==1
plot(xx.p{s},yy.p{s},'-.','LineWidth',2.5)
hold on
end
end
if roc==1
xlabel('False positive rate'); ylabel('True positive rate');
title('ROC of classification methods');
legend('L1-SVM,RBF','Discriminant Analysis','Classification Tree','Ensemble of 10 tree & adaboost method ','Naive Bayes','Linear Classification','L1-SVM,Linear','Location','Best')
ax = gca;
ax.FontSize = 18;
ax.LineWidth=2;
ax.YLim = [-0.05 1.05];
ax.XLim = [-0.05 1.05];
end

% fig=gcf;
% 
% fig.WindowState='fullscreen';
% fig.ToolBar='auto' ;
% 
% fig.DockControls='on';
% fig.MenuBar='none'