function z=MOP18(x,~)
global kh
switch kh
    case 2
z=MOP16(x);
    case 3 
z=MOP16(x);
    case 4
z=MOP17(x);
    case 5
z=MOP17(x); 
    case 6
z=MOP17(x);
    case 7
z=MOP17(x);
end